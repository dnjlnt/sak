<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

require './vendor/autoload.php';

class Intervensi extends CI_Controller {
	public function __construct() {
        parent::__construct();
		$this->load->library("pdfgenerator");
    }
	
	public function index() {
        $new_diag_record_number = $this->session->userdata('new_diag_record_number');

        $no = 0;
        $data["rowintervensi"] = "";
        $getAllInt = $this->ModelIntervensi->getAllInt($new_diag_record_number);
        if ($getAllInt !== false) {
            foreach ($getAllInt as $row) {
                $no++;
                $int_kep_name = $row->intervensi_keperawatan_name;
                $int_kep_name = strtoupper($int_kep_name);
                $int_kep_name = str_replace(' ', '_', $int_kep_name);
                $controller_name = $row->mapping_int_id;
                $int_record_id = $row->intervensi_record_id;
                $intervensi_status = $row->intervensi_status;

                $data["rowintervensi"] .= "<tr>
                                                <td style='width:50px;'>".$no.".</td>
                                                <td>
                                                    <a href='".base_url()."".$controller_name."?drm=".$new_diag_record_number."&int_record_id=".$int_record_id."&int_status=".$intervensi_status."&int_form=".$int_kep_name."'>
                                                        ".$row->intervensi_keperawatan_name."
                                                    </a>
                                                </td>
                                           </tr>";
            }
        } else {
            redirect("patient/patientinfo/00000002");
        }

        $this->load->view('intervensi/index.php', $data);
	}

    public function latihanbatukefektif() {
        $master_diag_record_number = $this->uri->segment(3);
        $int_record_id = $this->uri->segment(4);
        $form_intervensi_id = "I_KEP001";
        $created_by = "USER_001";
        $created_dttm = date("Y-m-d H:i:s");

        $data["buttonSave"] = "<button type='submit' onclick='saveLatihanBatuk(\"$master_diag_record_number\", \"$int_record_id\")' class='btn btn-primary'>
                                Save
                               </button>";

        $data["intervensicontent"] = "";
        $getSubIntervensi = $this->ModelIntervensi->getSubIntervensi($form_intervensi_id);
        if ($getSubIntervensi !== false) {
            foreach ($getSubIntervensi as $rowSub) {
                $data["intervensicontent"] .= "<div class='form-group mb-3'>
                                                    <label class='form-label' id='label'>
                                                        <b>".$rowSub->sub_intervensi_name."</b>
                                                    </label>
                                               </div>
                                               <div>";

                $getCheckboxIntervensi = $this->ModelIntervensi->getCheckboxIntervensi($rowSub->sub_intervensi_id);
                if ($getCheckboxIntervensi !== false) {
                    foreach ($getCheckboxIntervensi as $rowCheckbox) {
                        $data["intervensicontent"] .= "<label class='form-check'>
                                                            <input class='form-check-input' name='int_latbatukefektif' id='".$rowCheckbox->chckbx_sub_intervensi_id."' value='".$rowCheckbox->chckbx_sub_intervensi_id."' type='checkbox'>
                                                            <span class='form-check-label'>".$rowCheckbox->chckbx_sub_intervensi_name."</span>
                                                       </label>";
                    }
                }
                
                $data["intervensicontent"] .= "</div>";
            }
        } else {
            $data["intervensicontent"] .= "";
        }

        $this->load->view('intervensi/latihanbatukefektif_page.php', $data);
	}

    public function manajemenjalannafas() {
        $master_diag_record_number = $this->uri->segment(3);
        $int_record_id = $this->uri->segment(4);
        $form_intervensi_id = "I_KEP002";
        $created_by = "USER_001";
        $created_dttm = date("Y-m-d H:i:s");

        $data["buttonSave"] = "<button type='submit' onclick='savemanajamennafas(\"$master_diag_record_number\", \"$int_record_id\")' class='btn btn-primary'>
                                Save
                               </button>";

        $data["intervensicontent"] = "";
        $getSubIntervensi = $this->ModelIntervensi->getSubIntervensi($form_intervensi_id);
        if ($getSubIntervensi !== false) {
            foreach ($getSubIntervensi as $rowSub) {
                $data["intervensicontent"] .= "<div class='form-group mb-3'>
                                                    <label class='form-label' id='label'>
                                                        <b>".$rowSub->sub_intervensi_name."</b>
                                                    </label>
                                               </div>
                                               <div>";

                $getCheckboxIntervensi = $this->ModelIntervensi->getCheckboxIntervensi($rowSub->sub_intervensi_id);
                if ($getCheckboxIntervensi !== false) {
                    foreach ($getCheckboxIntervensi as $rowCheckbox) {
                        $data["intervensicontent"] .= "<label class='form-check'>
                                                            <input class='form-check-input' name='int_manjalannafas' id='".$rowCheckbox->chckbx_sub_intervensi_id."' value='".$rowCheckbox->chckbx_sub_intervensi_id."' type='checkbox'>
                                                            <span class='form-check-label'>".$rowCheckbox->chckbx_sub_intervensi_name."</span>
                                                       </label>";
                    }
                }
                
                $data["intervensicontent"] .= "</div>";
            }
        } else {
            $data["intervensicontent"] .= "";
        }

        $this->load->view('intervensi/manajemenjalannafas_page.php', $data);
	}

    public function pemantauanrespirasi() {
        $master_diag_record_number = $this->uri->segment(3);
        $int_record_id = $this->uri->segment(4);
        $form_intervensi_id = "I_KEP003";
        $created_by = "USER_001";
        $created_dttm = date("Y-m-d H:i:s");

        $data["buttonSave"] = "<button type='submit' onclick='savepemantauanrespirasi(\"$master_diag_record_number\", \"$int_record_id\")' class='btn btn-primary'>
                                Save
                               </button>";

        $data["intervensicontent"] = "";
        $getSubIntervensi = $this->ModelIntervensi->getSubIntervensi($form_intervensi_id);
        if ($getSubIntervensi !== false) {
            foreach ($getSubIntervensi as $rowSub) {
                $data["intervensicontent"] .= "<div class='form-group mb-3'>
                                                    <label class='form-label' id='label'>
                                                        <b>".$rowSub->sub_intervensi_name."</b>
                                                    </label>
                                               </div>
                                               <div>";

                $getCheckboxIntervensi = $this->ModelIntervensi->getCheckboxIntervensi($rowSub->sub_intervensi_id);
                if ($getCheckboxIntervensi !== false) {
                    foreach ($getCheckboxIntervensi as $rowCheckbox) {
                        $data["intervensicontent"] .= "<label class='form-check'>
                                                            <input class='form-check-input' name='int_pemrespirasi' id='".$rowCheckbox->chckbx_sub_intervensi_id."' value='".$rowCheckbox->chckbx_sub_intervensi_id."' type='checkbox'>
                                                            <span class='form-check-label'>".$rowCheckbox->chckbx_sub_intervensi_name."</span>
                                                       </label>";
                    }
                }
                
                $data["intervensicontent"] .= "</div>";
            }
        } else {
            $data["intervensicontent"] .= "";
        }

        $this->load->view('intervensi/pemantauanrespirasi_page.php', $data);
	}

    public function saveLatihanBatukEfektif() {
        $created_by = "USER_001";
        $created_dttm = date("Y-m-d H:i:s");
        $master_diag_record_number = $this->input->post("master_diag_record_number");
        $int_record_id = $this->input->post("int_record_id");

        foreach ($this->input->post("selectedIntervensi") as $row) {
            $saveProcess = $this->ModelIntervensi->saveLatihanBatuk($row, $master_diag_record_number, $int_record_id, $created_by, $created_dttm);
        }
        
        if ($saveProcess) {
            echo "success";
        } else {
            echo "failed";
        }
    }

    public function saveManajemenJalanNafas() {
        $created_by = "USER_001";
        $created_dttm = date("Y-m-d h:i:s");
        $master_diag_record_number = $this->input->post("master_diag_record_number");
        $int_record_id = $this->input->post("int_record_id");

        foreach ($this->input->post("selectedIntervensi") as $row) {
            $saveProcess = $this->ModelIntervensi->saveManajemenJalanNafas($row, $master_diag_record_number, $int_record_id, $created_by, $created_dttm);
        }
        
        if ($saveProcess) {
            echo "success";
        } else {
            echo "failed";
        }
    }

    public function savePemantauanRespirasi() {
        $created_by = "USER_001";
        $created_dttm = date("Y-m-d H:i:s");
        $master_diag_record_number = $this->input->post("master_diag_record_number");
        $int_record_id = $this->input->post("int_record_id");

        foreach ($this->input->post("selectedIntervensi") as $row) {
            $saveProcess = $this->ModelIntervensi->savePemantauanRespirasi($row, $master_diag_record_number, $int_record_id, $created_by, $created_dttm);
        }
        
        if ($saveProcess) {
            echo "success";
        } else {
            echo "failed";
        }
    }
}